import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import OpenAI

# 1. Initialize FastAPI App
app = FastAPI(title="Offline RAG Knowledge Portal")

# 2. Setup Connection to Local LLM (llama.cpp)
# We point base_url to port 8000 where your llama engine will run
client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="sk-no-key-required"
)

# 3. Define the Request Model (Data format)
class ChatRequest(BaseModel):
    query: str
    context: str = "No context provided."

# 4. Create the Chat Endpoint
@app.post("/generate")
async def generate_response(request: ChatRequest):
    try:
        # System Prompt: Strict instructions for the AI
        system_instruction = (
            "You are a helpful and precise assistant for an internal knowledge portal. "
            "Answer the user's question based ONLY on the provided context below. "
            "If the answer is not in the context, state that you do not know. "
            "Do not hallucinate facts."
        )

        # User Prompt: The actual data
        formatted_prompt = f"""
        ### Context:
        {request.context}

        ### Question:
        {request.query}
        """

        print(f"DEBUG: Sending query to llama.cpp...")

        # Call the llama.cpp server
        response = client.chat.completions.create(
            model="local-model", # Name is ignored by local server
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": formatted_prompt}
            ],
            temperature=0.1,       # Low temp for factual answers
            max_tokens=1024,       # Limit the answer length
            stream=False
        )

        # Extract the answer
        ai_answer = response.choices[0].message.content
        return {"response": ai_answer}

    except Exception as e:
        print(f"Error communicating with LLM: {e}")
        raise HTTPException(status_code=500, detail=f"LLM Server Error: {str(e)}")

# 5. Run the Server
if __name__ == "__main__":
    # Runs on Port 8080 to avoid conflict with llama.cpp (Port 8000)
    uvicorn.run(app, host="0.0.0.0", port=8080)